﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Proje
{
    public partial class Main : Form
    {
        public Main()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            
            
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            
            Girisyap girisyap = new Girisyap();
            girisyap.Visible = true;
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox4_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox5_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox6_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox7_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox8_Click(object sender, EventArgs e)
        {

        }

        private void textBox7_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void Enter(object sender, EventArgs e)
        {
            if(aramacubugu.Text !="")
            {
                aramacubugu.Text = "";
            }
        }

        private void Leave(object sender, EventArgs e)
        {
            aramacubugu.Text = "Al-sat'da ara...";
        }

        private void Main_Load(object sender, EventArgs e)
        {
            mainpanel.AutoScroll = false;
            mainpanel.HorizontalScroll.Enabled = false;
            mainpanel.HorizontalScroll.Visible = false;
            mainpanel.HorizontalScroll.Maximum = 0;
            mainpanel.AutoScroll = true;
        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {
            panel2.Location = new Point(0, 0);
           
        }
    }
}
